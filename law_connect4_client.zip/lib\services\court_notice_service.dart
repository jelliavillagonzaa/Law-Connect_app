import 'dart:typed_data';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/foundation.dart' show kIsWeb;

import '../models/case_model.dart';
import '../models/court_message_extraction.dart';
import 'admin_service.dart';
import 'court_notice_rule_extractor.dart';
import 'court_notice_text_extractor.dart';
import 'legal_assistant_cloud_parser.dart';
import 'legal_assistant_settings_service.dart';
import 'staff_service.dart';

/// Orchestrates extraction and scheduling a `calendar_events` hearing (same shape as staff calendar).
class CourtNoticeService {
  CourtNoticeService({
    StaffService? staffService,
    LegalAssistantSettingsService? settingsService,
    AdminService? adminService,
  })  : _staffService = staffService ?? StaffService(),
        _settingsService = settingsService ?? LegalAssistantSettingsService(),
        _adminService = adminService ?? AdminService();

  final StaffService _staffService;
  final LegalAssistantSettingsService _settingsService;
  final AdminService _adminService;
  final CourtNoticeTextExtractor _textExtractor = CourtNoticeTextExtractor();
  final CourtNoticeRuleExtractor _rules = CourtNoticeRuleExtractor();

  Future<CourtMessageExtraction> extractFromPlainText(String text) async {
    final app = await _settingsService.loadAppSettings();
    var baseline = _rules.extract(text);
    final url = app.extractionApiUrl;
    if (url != null && url.isNotEmpty) {
      final enhanced = await LegalAssistantCloudParser().tryEnhance(
        url: url,
        text: text,
        baseline: baseline,
      );
      if (enhanced != null) {
        baseline = enhanced;
      }
    }
    return baseline;
  }

  Future<String> textFromPdfBytes(Uint8List bytes) =>
      _textExtractor.extractFromPdfBytes(bytes);

  Future<String> textFromImagePath(String path) =>
      _textExtractor.extractFromImagePath(path);

  /// Match a case for this attorney using extracted case number / title hints.
  Future<CaseModel?> resolveCase({
    required String attorneyId,
    required CourtMessageExtraction ext,
    List<CaseModel>? attorneyCases,
  }) async {
    List<CaseModel> cases;
    if (attorneyCases != null) {
      cases = attorneyCases;
    } else {
      final snap = await FirebaseFirestore.instance
          .collection('cases')
          .where('attorneyId', isEqualTo: attorneyId)
          .limit(100)
          .get();
      cases = snap.docs.map(CaseModel.fromFirestore).toList();
    }

    final num = ext.caseNumber?.trim().toLowerCase();
    if (num != null && num.isNotEmpty) {
      for (final c in cases) {
        if (c.caseTitle.toLowerCase().contains(num)) return c;
        if (c.caseDescription.toLowerCase().contains(num)) return c;
        if (c.caseType.toLowerCase().contains(num)) return c;
      }
    }
    final party = (ext.defendant ?? ext.plaintiff ?? '').trim().toLowerCase();
    if (party.isNotEmpty) {
      for (final c in cases) {
        if (c.caseTitle.toLowerCase().contains(party)) return c;
      }
    }
    return null;
  }

  Future<Map<String, dynamic>> scheduleHearingFromExtraction({
    required CourtMessageExtraction extraction,
    required String attorneyId,
    required String actorRole,
    String? caseId,
    String? clientId,
    String? titleOverride,
  }) async {
    final dt = extraction.hearingDateTime;
    if (dt == null) {
      return {'success': false, 'message': 'Hearing date and time are required.'};
    }
    if (attorneyId.isEmpty) {
      return {
        'success': false,
        'message': 'No attorney assigned. Staff must have an assigned attorney.',
      };
    }

    final title = (titleOverride != null && titleOverride.trim().isNotEmpty)
        ? titleOverride.trim()
        : extraction.suggestedTitle();
    final description = extraction.buildDescription();

    final clientIds = <String>[];
    if (clientId != null && clientId.isNotEmpty) {
      clientIds.add(clientId);
    }

    final result = await _staffService.createCalendarEvent(
      eventType: 'hearing',
      eventDate: dt,
      title: title,
      description: description.isEmpty ? null : description,
      caseId: caseId,
      assignedTo: attorneyId,
      clientId: clientId,
      remindAttorney: true,
      remindClient: clientIds.isNotEmpty,
      selectedClientIds: clientIds,
      sendNow: true,
      notifyStaff: true,
      createdByRole: actorRole,
      extraFields: const {
        'source': 'legal_assistant',
      },
    );

    final user = FirebaseAuth.instance.currentUser;
    if (result['success'] == true && user != null) {
      await _adminService.logAction(
        action: 'Legal assistant: hearing scheduled',
        details:
            'Title: $title | Case: ${caseId ?? '—'} | Attorney: $attorneyId',
        resourceType: 'calendar',
        resourceId: null,
        metadata: {
          'source': 'legal_assistant',
          'eventDate': dt.toIso8601String(),
          'actorUid': user.uid,
          'actorRole': actorRole,
        },
      );
      await _staffService.logActivity(
        action: 'Legal assistant hearing scheduled',
        details: title,
        resourceType: 'calendar',
        resourceId: null,
      );
    }

    return result;
  }

  bool get imageOcrSupported => !kIsWeb && _textExtractor.imageOcrSupported;
}
