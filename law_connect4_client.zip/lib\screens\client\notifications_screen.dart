import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../../theme/app_theme.dart';
import '../../widgets/empty_state.dart';
import '../../services/auth_service.dart';

class NotificationsScreen extends StatefulWidget {
  const NotificationsScreen({super.key});

  @override
  State<NotificationsScreen> createState() => _NotificationsScreenState();
}

class _NotificationsScreenState extends State<NotificationsScreen> {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final AuthService _authService = AuthService();
  bool _isMarkingAllRead = false;

  // Get all notifications for user (checking both userId and clientId)
  Stream<List<Map<String, dynamic>>> _notificationsStream(String userId) {
    // Use userId query as primary, then merge with clientId results
    return _firestore
        .collection('notifications')
        .where('userId', isEqualTo: userId)
        .snapshots()
        .asyncMap((userIdSnapshot) async {
          // Also get notifications by clientId
          final clientIdSnapshot = await _firestore
              .collection('notifications')
              .where('clientId', isEqualTo: userId)
              .get();

          // Combine both results and remove duplicates
          final allNotifications = <String, Map<String, dynamic>>{};

          // Add notifications from userId query
          for (var doc in userIdSnapshot.docs) {
            final data = doc.data();
            data['id'] = doc.id;
            allNotifications[doc.id] = data;
          }

          // Add notifications from clientId query (will overwrite duplicates)
          for (var doc in clientIdSnapshot.docs) {
            final data = doc.data();
            data['id'] = doc.id;
            allNotifications[doc.id] = data;
          }

          // Convert to list and sort by createdAt
          final notificationsList = allNotifications.values.toList();
          notificationsList.sort((a, b) {
            final aTime =
                (a['createdAt'] as Timestamp?)?.toDate() ?? DateTime(1970);
            final bTime =
                (b['createdAt'] as Timestamp?)?.toDate() ?? DateTime(1970);
            return bTime.compareTo(aTime); // Descending order
          });

          return notificationsList;
        });
  }

  Future<void> _markAllAsRead(String userId) async {
    if (_isMarkingAllRead) return;
    setState(() {
      _isMarkingAllRead = true;
    });

    try {
      // Get unread notifications from both userId and clientId
      final userIdQuery = await _firestore
          .collection('notifications')
          .where('userId', isEqualTo: userId)
          .where('isRead', isEqualTo: false)
          .get();

      final clientIdQuery = await _firestore
          .collection('notifications')
          .where('clientId', isEqualTo: userId)
          .where('isRead', isEqualTo: false)
          .get();

      // Combine and remove duplicates
      final allDocIds = <String>{};
      for (var doc in userIdQuery.docs) {
        allDocIds.add(doc.id);
      }
      for (var doc in clientIdQuery.docs) {
        allDocIds.add(doc.id);
      }

      final batch = _firestore.batch();
      for (var docId in allDocIds) {
        final docRef = _firestore.collection('notifications').doc(docId);
        batch.update(docRef, {'isRead': true});
      }
      await batch.commit();
    } catch (_) {
      // Ignore errors for now; UI will simply still show unread indicators
    } finally {
      if (mounted) {
        setState(() {
          _isMarkingAllRead = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final user = _authService.currentUser;

    if (user == null) {
      return Scaffold(
        backgroundColor: AppTheme.lightBackground,
        appBar: AppBar(title: const Text('Notifications')),
        body: const Center(child: Text('Not logged in')),
      );
    }

    return Scaffold(
      backgroundColor: AppTheme.lightBackground,
      appBar: AppBar(
        title: const Text('Notifications'),
        backgroundColor: AppTheme.royalBlue,
        iconTheme: const IconThemeData(color: AppTheme.white),
        actions: [
          TextButton(
            onPressed: _isMarkingAllRead
                ? null
                : () => _markAllAsRead(user.uid),
            child: Text(
              _isMarkingAllRead ? 'Marking...' : 'Mark all read',
              style: AppTheme.bodyMedium.copyWith(color: AppTheme.white),
            ),
          ),
        ],
      ),
      body: StreamBuilder<List<Map<String, dynamic>>>(
        stream: _notificationsStream(user.uid),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          if (snapshot.hasError) {
            return EmptyState(
              icon: Icons.error_outline,
              title: 'Error loading notifications',
              message: snapshot.error?.toString() ?? 'Please try again later.',
            );
          }

          final notifications = snapshot.data ?? [];

          if (notifications.isEmpty) {
            return const EmptyState(
              icon: Icons.notifications_outlined,
              title: 'No Notifications',
              message: 'You\'re all caught up!',
            );
          }

          return ListView.builder(
            itemCount: notifications.length,
            itemBuilder: (context, index) {
              final data = notifications[index];
              final notificationId = data['id'] as String? ?? '';
              final createdAtTs = data['createdAt'] as Timestamp?;
              final createdAt = createdAtTs?.toDate();
              final timeLabel = createdAt != null
                  ? DateFormat('MMM dd, yyyy – hh:mm a').format(createdAt)
                  : 'Just now';

              final isRead = (data['isRead'] as bool?) ?? false;
              final notificationType = data['type'] as String? ?? 'general';

              // Get appropriate icon based on notification type
              IconData notificationIcon = Icons.notifications_outlined;
              Color iconColor = AppTheme.navy;

              if (notificationType.contains('message') ||
                  notificationType.contains('chat')) {
                notificationIcon = Icons.message_outlined;
                iconColor = AppTheme.royalBlue;
              } else if (notificationType.contains('case')) {
                notificationIcon = Icons.folder_outlined;
                iconColor = AppTheme.royalBlue;
              } else if (notificationType.contains('appointment')) {
                notificationIcon = Icons.calendar_today_outlined;
                iconColor = AppTheme.gold;
              }

              return Card(
                margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                child: ListTile(
                  leading: Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: iconColor.withValues(alpha: 0.1),
                      shape: BoxShape.circle,
                    ),
                    child: Icon(notificationIcon, color: iconColor, size: 20),
                  ),
                  title: Text(
                    (data['title'] as String?) ?? 'Notification',
                    style: AppTheme.bodyLarge.copyWith(
                      fontWeight: isRead ? FontWeight.normal : FontWeight.w600,
                    ),
                  ),
                  subtitle: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const SizedBox(height: 4),
                      Text(
                        (data['message'] as String?) ?? 'Notification message',
                        style: AppTheme.bodySmall.copyWith(
                          fontWeight: isRead
                              ? FontWeight.normal
                              : FontWeight.w500,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(timeLabel, style: AppTheme.caption),
                    ],
                  ),
                  trailing: isRead
                      ? null
                      : Container(
                          width: 8,
                          height: 8,
                          decoration: const BoxDecoration(
                            color: AppTheme.navy,
                            shape: BoxShape.circle,
                          ),
                        ),
                  onTap: () async {
                    // Mark single notification as read on tap
                    if (!isRead && notificationId.isNotEmpty) {
                      try {
                        await _firestore
                            .collection('notifications')
                            .doc(notificationId)
                            .update({'isRead': true});
                      } catch (_) {
                        // Ignore failures
                      }
                    }
                  },
                ),
              );
            },
          );
        },
      ),
    );
  }
}
