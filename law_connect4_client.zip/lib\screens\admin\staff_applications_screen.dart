import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../services/admin_service.dart';
import '../../services/staff_application_service.dart';
import '../../theme/app_theme.dart';

/// Admin: review pending staff applications, assign attorney, approve or reject.
class StaffApplicationsScreen extends StatefulWidget {
  const StaffApplicationsScreen({super.key, this.inline = false});

  final bool inline;

  @override
  State<StaffApplicationsScreen> createState() =>
      _StaffApplicationsScreenState();
}

class _StaffApplicationsScreenState extends State<StaffApplicationsScreen> {
  final _applicationService = StaffApplicationService();
  final _adminService = AdminService();
  final _firestore = FirebaseFirestore.instance;

  List<DropdownMenuItem<String>> _attorneyItems = [];
  bool _loadingAttorneys = true;

  @override
  void initState() {
    super.initState();
    _loadAttorneys();
  }

  Future<void> _loadAttorneys() async {
    try {
      final snap = await _firestore
          .collection('users')
          .where('role', isEqualTo: 'attorney')
          .where('isActive', isEqualTo: true)
          .limit(50)
          .get();

      final items = snap.docs.map((d) {
        final name = d.data()['name'] as String? ?? 'Attorney';
        return DropdownMenuItem<String>(
          value: d.id,
          child: Text(
            '$name (${d.data()['email'] ?? d.id})',
            overflow: TextOverflow.ellipsis,
          ),
        );
      }).toList();

      if (mounted) {
        setState(() {
          _attorneyItems = items;
          _loadingAttorneys = false;
        });
      }
    } catch (_) {
      if (mounted) setState(() => _loadingAttorneys = false);
    }
  }

  Future<void> _approve(String docId) async {
    if (_attorneyItems.isEmpty) {
      Get.snackbar(
        'No attorneys',
        'Add an active attorney before approving staff.',
        backgroundColor: Colors.orange,
        colorText: Colors.white,
      );
      return;
    }

    String? selectedAttorney = _attorneyItems.first.value;

    final chosen = await showDialog<String>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (context, setDialogState) {
          return AlertDialog(
            title: const Text('Approve staff application'),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const Text('Assign supervising attorney:'),
                const SizedBox(height: 12),
                DropdownButtonFormField<String>(
                  value: selectedAttorney,
                  items: _attorneyItems,
                  decoration: const InputDecoration(
                    border: OutlineInputBorder(),
                    isDense: true,
                  ),
                  onChanged: (v) => setDialogState(() => selectedAttorney = v),
                ),
              ],
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(ctx),
                child: const Text('Cancel'),
              ),
              ElevatedButton(
                onPressed: () => Navigator.pop(ctx, selectedAttorney),
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppTheme.royalBlue,
                  foregroundColor: Colors.white,
                ),
                child: const Text('Approve'),
              ),
            ],
          );
        },
      ),
    );

    if (chosen == null || chosen.isEmpty) return;

    final admin = FirebaseAuth.instance.currentUser;
    if (admin == null) return;

    final res = await _applicationService.approveApplication(
      docId: docId,
      assignedAttorneyId: chosen,
      adminUid: admin.uid,
    );

    if (res['success'] == true) {
      await _adminService.logAction(
        action: 'staff_application_approved',
        details: 'Application $docId approved, attorney $chosen',
        resourceType: 'staff_applications',
        resourceId: docId,
      );
    }

    if (mounted) {
      Get.snackbar(
        res['success'] == true ? 'Approved' : 'Error',
        res['message'] as String? ?? '',
        backgroundColor:
            res['success'] == true ? Colors.green : Colors.red,
        colorText: Colors.white,
      );
    }
  }

  Future<void> _reject(String docId) async {
    final reasonController = TextEditingController();

    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Reject application'),
        content: TextField(
          controller: reasonController,
          decoration: const InputDecoration(
            labelText: 'Reason (optional)',
            border: OutlineInputBorder(),
          ),
          maxLines: 3,
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(ctx, true),
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            child: const Text('Reject'),
          ),
        ],
      ),
    );

    if (ok != true) return;

    final admin = FirebaseAuth.instance.currentUser;
    if (admin == null) return;

    final res = await _applicationService.rejectApplication(
      docId: docId,
      adminUid: admin.uid,
      reason: reasonController.text,
    );

    if (res['success'] == true) {
      await _adminService.logAction(
        action: 'staff_application_rejected',
        details: 'Application $docId rejected',
        resourceType: 'staff_applications',
        resourceId: docId,
      );
    }

    if (mounted) {
      Get.snackbar(
        res['success'] == true ? 'Rejected' : 'Error',
        res['message'] as String? ?? '',
        backgroundColor:
            res['success'] == true ? Colors.orange : Colors.red,
        colorText: Colors.white,
      );
    }
  }

  Future<void> _delete(String docId) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Remove application'),
        content: const Text(
          'Delete this record so the applicant can submit again (e.g. after a rejection).',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Delete', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );

    if (ok != true) return;

    final res = await _applicationService.deleteApplication(docId);
    if (res['success'] == true) {
      await _adminService.logAction(
        action: 'staff_application_deleted',
        details: docId,
        resourceType: 'staff_applications',
        resourceId: docId,
      );
    }

    if (mounted) {
      Get.snackbar(
        res['success'] == true ? 'Removed' : 'Error',
        res['message'] as String? ?? '',
        backgroundColor:
            res['success'] == true ? Colors.grey : Colors.red,
        colorText: Colors.white,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final header = Padding(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Staff applications',
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                  fontWeight: FontWeight.bold,
                  color: AppTheme.royalBlue,
                ),
          ),
          const SizedBox(height: 8),
          Text(
            'Review requests for staff access. Approve only after verifying the applicant; assign a supervising attorney.',
            style: TextStyle(color: Colors.grey[700], fontSize: 14),
          ),
          const SizedBox(height: 16),
          if (_loadingAttorneys)
            const LinearProgressIndicator()
          else if (_attorneyItems.isEmpty)
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Text(
                  'No active attorneys found. Create an attorney account before approving staff.',
                  style: TextStyle(color: Colors.orange[900]),
                ),
              ),
            ),
          const SizedBox(height: 8),
        ],
      ),
    );

    final list = Expanded(
      child: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: _applicationService.watchAllApplications(),
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Text(
                  'Could not load applications.\n'
                  '${snapshot.error}\n'
                  'Deploy updated Firestore rules if this persists.',
                  textAlign: TextAlign.center,
                ),
              ),
            );
          }
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }

          final docs = snapshot.data!.docs;
          if (docs.isEmpty) {
            return const Center(child: Text('No applications yet.'));
          }

          return ListView.separated(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
            itemCount: docs.length,
            separatorBuilder: (_, __) => const SizedBox(height: 10),
            itemBuilder: (context, i) {
              final doc = docs[i];
              final d = doc.data();
              final status = d['status'] as String? ?? '';
              final name = d['name'] as String? ?? '';
              final email = d['email'] as String? ?? '';
              final phone = d['phone'] as String? ?? '';
              final message = d['message'] as String? ?? '';
              final reason = d['rejectionReason'] as String? ?? '';

              return Card(
                elevation: 1,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          _StatusPill(status),
                          const Spacer(),
                          if (status == 'pending')
                            TextButton.icon(
                              onPressed: () => _approve(doc.id),
                              icon: const Icon(Icons.check_circle_outline),
                              label: const Text('Approve'),
                            ),
                          if (status == 'pending')
                            TextButton.icon(
                              onPressed: () => _reject(doc.id),
                              icon:
                                  const Icon(Icons.close, color: Colors.red),
                              label: const Text(
                                'Reject',
                                style: TextStyle(color: Colors.red),
                              ),
                            ),
                          if (status == 'rejected')
                            IconButton(
                              tooltip: 'Delete so applicant can re-apply',
                              onPressed: () => _delete(doc.id),
                              icon: const Icon(Icons.delete_outline),
                            ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      Text(
                        name,
                        style: const TextStyle(
                          fontSize: 17,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      Text(email),
                      if (phone.isNotEmpty) Text(phone),
                      if (message.isNotEmpty) ...[
                        const SizedBox(height: 8),
                        Text(
                          message,
                          style: TextStyle(
                            color: Colors.grey[800],
                            fontSize: 13,
                          ),
                        ),
                      ],
                      if (reason.isNotEmpty && status == 'rejected') ...[
                        const SizedBox(height: 8),
                        Text(
                          'Reason: $reason',
                          style: const TextStyle(
                            color: Colors.red,
                            fontSize: 13,
                          ),
                        ),
                      ],
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
    );

    final column = Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        header,
        list,
      ],
    );

    if (widget.inline) {
      return column;
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Staff applications'),
        backgroundColor: AppTheme.royalBlue,
        foregroundColor: Colors.white,
      ),
      body: column,
    );
  }
}

class _StatusPill extends StatelessWidget {
  const _StatusPill(this.status);

  final String status;

  @override
  Widget build(BuildContext context) {
    Color c;
    switch (status) {
      case 'pending':
        c = Colors.orange;
        break;
      case 'approved':
        c = Colors.green;
        break;
      case 'rejected':
        c = Colors.red;
        break;
      case 'registered':
        c = AppTheme.royalBlue;
        break;
      default:
        c = Colors.grey;
    }
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: c.withValues(alpha: 0.15),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: c.withValues(alpha: 0.5)),
      ),
      child: Text(
        status.toUpperCase(),
        style: TextStyle(
          fontSize: 11,
          fontWeight: FontWeight.w700,
          color: c,
        ),
      ),
    );
  }
}
