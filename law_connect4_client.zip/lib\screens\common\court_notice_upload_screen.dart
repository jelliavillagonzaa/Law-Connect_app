import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:file_picker/file_picker.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:intl/intl.dart';

import '../../models/case_model.dart';
import '../../models/court_message_extraction.dart';
import '../../services/court_notice_service.dart';
import '../../services/legal_assistant_settings_service.dart';
import '../../services/staff_auth_service.dart';
import '../../theme/app_theme.dart';
import '../../utils/temp_file_for_ocr.dart';

/// Upload PDF or image → extract → review → create `calendar_events` hearing (same as staff calendar).
class CourtNoticeUploadScreen extends StatefulWidget {
  const CourtNoticeUploadScreen({super.key});

  @override
  State<CourtNoticeUploadScreen> createState() =>
      _CourtNoticeUploadScreenState();
}

class _CourtNoticeUploadScreenState extends State<CourtNoticeUploadScreen> {
  final CourtNoticeService _courtNoticeService = CourtNoticeService();
  final LegalAssistantSettingsService _settingsService =
      LegalAssistantSettingsService();
  final StaffAuthService _staffAuthService = StaffAuthService();

  final TextEditingController _titleController = TextEditingController();

  bool _loadingPermission = true;
  bool _allowed = false;
  String? _blockMessage;

  String? _attorneyId;
  String _actorRole = 'staff';

  CourtMessageExtraction? _extracted;
  DateTime? _hearingDateTime;
  String? _selectedCaseId;

  bool _busy = false;

  @override
  void dispose() {
    _titleController.dispose();
    super.dispose();
  }

  @override
  void initState() {
    super.initState();
    _initAccess();
  }

  Future<void> _initAccess() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) {
      setState(() {
        _loadingPermission = false;
        _allowed = false;
        _blockMessage = 'You must be signed in.';
      });
      return;
    }

    final can = await _settingsService.canUseFeature();
    if (!can) {
      setState(() {
        _loadingPermission = false;
        _allowed = false;
        _blockMessage =
            'Legal assistant is disabled or your role is not permitted.';
      });
      return;
    }

    try {
      final doc = await FirebaseFirestore.instance
          .collection('users')
          .doc(user.uid)
          .get();
      final data = doc.data();
      final role = data?['role'] as String? ?? 'client';

      if (role == 'staff') {
        final staff = await _staffAuthService.getCurrentStaff();
        final aid = staff?.assignedAttorneyId;
        setState(() {
          _actorRole = 'staff';
          _attorneyId = aid;
          _loadingPermission = false;
          _allowed = aid != null && aid.isNotEmpty;
          if (!_allowed) {
            _blockMessage =
                'You have no assigned attorney. Calendar events require an attorney.';
          }
        });
        return;
      }

      if (role == 'attorney') {
        setState(() {
          _actorRole = 'attorney';
          _attorneyId = user.uid;
          _loadingPermission = false;
          _allowed = true;
        });
        return;
      }

      if (role == 'admin') {
        setState(() {
          _actorRole = 'admin';
          _attorneyId = user.uid;
          _loadingPermission = false;
          _allowed = true;
          _blockMessage =
              'Admin: hearings will be assigned to your user ID as attorney unless you use a staff account with an assigned attorney.';
        });
        return;
      }

      setState(() {
        _loadingPermission = false;
        _allowed = false;
        _blockMessage = 'Your role cannot use this tool.';
      });
    } catch (e) {
      setState(() {
        _loadingPermission = false;
        _allowed = false;
        _blockMessage = e.toString();
      });
    }
  }

  CourtMessageExtraction _mergedExtraction() {
    final base = _extracted ?? const CourtMessageExtraction();
    return CourtMessageExtraction(
      hearingDateTime: _hearingDateTime ?? base.hearingDateTime,
      courtName: base.courtName,
      judge: base.judge,
      caseNumber: base.caseNumber,
      plaintiff: base.plaintiff,
      defendant: base.defendant,
      attorneyMentioned: base.attorneyMentioned,
      clientMentioned: base.clientMentioned,
      roomOrBranch: base.roomOrBranch,
      summaryNotes: base.summaryNotes,
    );
  }

  Future<void> _pickFile() async {
    if (!_allowed || _attorneyId == null) return;

    setState(() => _busy = true);
    try {
      final result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: const ['pdf', 'png', 'jpg', 'jpeg', 'webp'],
        withData: true,
      );

      if (result == null || result.files.isEmpty) {
        setState(() => _busy = false);
        return;
      }

      final f = result.files.single;
      final name = f.name.toLowerCase();
      late final String rawText;

      if (name.endsWith('.pdf')) {
        final bytes = f.bytes;
        if (bytes == null || bytes.isEmpty) {
          _toast('Could not read PDF bytes. Try a smaller file.');
          setState(() => _busy = false);
          return;
        }
        rawText = await _courtNoticeService.textFromPdfBytes(bytes);
      } else {
        String? path = f.path;
        if ((path == null || path.isEmpty) && f.bytes != null) {
          path = await writeTempBytesForOcr(f.bytes!);
        }
        if (path == null || path.isEmpty) {
          _toast('Could not access image file.');
          setState(() => _busy = false);
          return;
        }
        if (!_courtNoticeService.imageOcrSupported) {
          _toast(
            'Image OCR runs on mobile/desktop. On web, upload a text-based PDF.',
          );
          setState(() => _busy = false);
          return;
        }
        rawText = await _courtNoticeService.textFromImagePath(path);
      }

      if (rawText.trim().isEmpty) {
        _toast('No text extracted. Try a clearer scan or a text PDF.');
        setState(() => _busy = false);
        return;
      }

      final extraction = await _courtNoticeService.extractFromPlainText(rawText);
      final casesSnap = await FirebaseFirestore.instance
          .collection('cases')
          .where('attorneyId', isEqualTo: _attorneyId)
          .limit(100)
          .get();
      final cases = casesSnap.docs.map(CaseModel.fromFirestore).toList();
      final matched = await _courtNoticeService.resolveCase(
        attorneyId: _attorneyId!,
        ext: extraction,
        attorneyCases: cases,
      );

      if (!mounted) return;

      setState(() {
        _extracted = extraction;
        _hearingDateTime = extraction.hearingDateTime;
        _titleController.text = extraction.suggestedTitle();
        _selectedCaseId = matched?.id;
        _busy = false;
      });

      final auto =
          await _settingsService.effectiveAutoCreateWithoutConfirm();
      if (auto &&
          extraction.hearingDateTime != null &&
          mounted &&
          _attorneyId != null) {
        await _runSchedule(
          extraction: _mergedExtraction(),
          title: _titleController.text.trim(),
          caseId: _selectedCaseId,
          clientId: matched?.clientId,
          popOnSuccess: false,
        );
      }
    } catch (e) {
      if (mounted) {
        _toast('Error: $e');
        setState(() => _busy = false);
      }
    }
  }

  Future<void> _pickDateTime() async {
    final initial = _hearingDateTime ?? DateTime.now();
    final d = await showDatePicker(
      context: context,
      initialDate: initial,
      firstDate: DateTime(2000),
      lastDate: DateTime(2100),
    );
    if (d == null || !mounted) return;
    final t = await showTimePicker(
      context: context,
      initialTime: TimeOfDay(hour: initial.hour, minute: initial.minute),
    );
    if (t == null || !mounted) return;
    setState(() {
      _hearingDateTime = DateTime(d.year, d.month, d.day, t.hour, t.minute);
    });
  }

  Future<void> _runSchedule({
    required CourtMessageExtraction extraction,
    required String title,
    String? caseId,
    String? clientId,
    required bool popOnSuccess,
  }) async {
    final attorneyId = _attorneyId;
    if (attorneyId == null || attorneyId.isEmpty) {
      _toast('Missing attorney.');
      return;
    }
    if (title.isEmpty) {
      _toast('Title is required.');
      return;
    }

    setState(() => _busy = true);
    try {
      final r = await _courtNoticeService.scheduleHearingFromExtraction(
        extraction: extraction,
        attorneyId: attorneyId,
        actorRole: _actorRole,
        caseId: caseId,
        clientId: clientId,
        titleOverride: title,
      );
      if (!mounted) return;
      setState(() => _busy = false);
      if (r['success'] == true) {
        _toast(popOnSuccess
            ? 'Hearing scheduled.'
            : 'Hearing auto-scheduled from notice.');
        if (popOnSuccess) Navigator.of(context).pop();
      } else {
        _toast(r['message']?.toString() ?? 'Failed to schedule');
      }
    } catch (e) {
      if (mounted) {
        setState(() => _busy = false);
        _toast('$e');
      }
    }
  }

  void _toast(String m) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));
  }

  @override
  Widget build(BuildContext context) {
    if (_loadingPermission) {
      return Scaffold(
        appBar: AppBar(title: const Text('Court notice assistant')),
        body: const Center(child: CircularProgressIndicator()),
      );
    }

    if (!_allowed) {
      return Scaffold(
        appBar: AppBar(
          title: const Text('Court notice assistant'),
          backgroundColor: AppTheme.royalBlue,
        ),
        body: Padding(
          padding: const EdgeInsets.all(24),
          child: Text(
            _blockMessage ?? 'Unavailable',
            style: const TextStyle(fontSize: 16),
          ),
        ),
      );
    }

    final dateStr = _hearingDateTime != null
        ? DateFormat('EEE, MMM d, yyyy • h:mm a').format(_hearingDateTime!)
        : 'Not set';

    return Scaffold(
      appBar: AppBar(
        title: const Text('Court notice assistant'),
        backgroundColor: AppTheme.royalBlue,
        foregroundColor: Colors.white,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            if (_actorRole == 'admin' && _blockMessage != null)
              Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: Text(
                  _blockMessage!,
                  style: TextStyle(
                    color: Colors.orange.shade900,
                    fontSize: 13,
                  ),
                ),
              ),
            Text(
              'PDF or image',
              style: Theme.of(context).textTheme.titleMedium,
            ),
            const SizedBox(height: 8),
            Text(
              kIsWeb
                  ? 'Web: use a text-based PDF. Image OCR runs on mobile/desktop.'
                  : 'Rule-based English parsing; optional API refines fields.',
              style: TextStyle(color: Colors.grey.shade700, fontSize: 13),
            ),
            const SizedBox(height: 16),
            FilledButton.icon(
              onPressed: _busy ? null : _pickFile,
              icon: const Icon(Icons.upload_file),
              label: const Text('Choose PDF or image'),
            ),
            if (_busy) const LinearProgressIndicator(),
            const SizedBox(height: 24),
            if (_extracted != null) ...[
              Text('Review', style: Theme.of(context).textTheme.titleMedium),
              const SizedBox(height: 12),
              TextField(
                controller: _titleController,
                decoration: const InputDecoration(
                  labelText: 'Event title',
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 12),
              ListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('Hearing date & time'),
                subtitle: Text(dateStr),
                trailing: IconButton(
                  icon: const Icon(Icons.edit_calendar),
                  onPressed: _pickDateTime,
                ),
              ),
              const SizedBox(height: 8),
              StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
                stream: FirebaseFirestore.instance
                    .collection('cases')
                    .where('attorneyId', isEqualTo: _attorneyId)
                    .limit(100)
                    .snapshots(),
                builder: (context, snap) {
                  if (!snap.hasData) {
                    return const SizedBox(
                      height: 48,
                      child: Center(child: CircularProgressIndicator()),
                    );
                  }
                  final cases =
                      snap.data!.docs.map(CaseModel.fromFirestore).toList();
                  return DropdownButtonFormField<String?>(
                    // ignore: deprecated_member_use
                    value: _selectedCaseId != null &&
                            cases.any((c) => c.id == _selectedCaseId)
                        ? _selectedCaseId
                        : null,
                    decoration: const InputDecoration(
                      labelText: 'Link case (optional)',
                      border: OutlineInputBorder(),
                    ),
                    items: [
                      const DropdownMenuItem<String?>(
                        value: null,
                        child: Text('— None —'),
                      ),
                      ...cases.map(
                        (c) => DropdownMenuItem(
                          value: c.id,
                          child: Text(
                            c.caseTitle,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      ),
                    ],
                    onChanged: (v) => setState(() => _selectedCaseId = v),
                  );
                },
              ),
              const SizedBox(height: 16),
              ExpansionTile(
                title: const Text('Extracted details'),
                children: [
                  Padding(
                    padding: const EdgeInsets.all(12),
                    child: SelectableText(
                      _mergedExtraction().buildDescription().isEmpty
                          ? '(No extra fields)'
                          : _mergedExtraction().buildDescription(),
                      style: const TextStyle(fontSize: 13),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 20),
              FilledButton(
                onPressed: _busy
                    ? null
                    : () async {
                        String? clientId;
                        if (_selectedCaseId != null) {
                          try {
                            final d = await FirebaseFirestore.instance
                                .collection('cases')
                                .doc(_selectedCaseId!)
                                .get();
                            clientId = d.data()?['clientId'] as String?;
                          } catch (_) {}
                        }
                        await _runSchedule(
                          extraction: _mergedExtraction(),
                          title: _titleController.text.trim(),
                          caseId: _selectedCaseId,
                          clientId: clientId,
                          popOnSuccess: true,
                        );
                      },
                child: const Text('Schedule hearing on calendar'),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
