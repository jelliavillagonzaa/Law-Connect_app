import 'dart:typed_data';

import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:syncfusion_flutter_pdf/pdf.dart';

import 'court_ocr_mobile.dart';

/// Pull plain text from PDF bytes (Syncfusion) or run OCR on an image file path (ML Kit).
class CourtNoticeTextExtractor {
  Future<String> extractFromPdfBytes(Uint8List bytes) async {
    if (bytes.isEmpty) return '';
    final doc = PdfDocument(inputBytes: bytes);
    try {
      return PdfTextExtractor(doc).extractText();
    } catch (_) {
      return '';
    } finally {
      doc.dispose();
    }
  }

  /// [imagePath] must be a local filesystem path (mobile/desktop).
  Future<String> extractFromImagePath(String imagePath) async {
    if (imagePath.isEmpty) return '';
    return extractTextFromImagePath(imagePath);
  }

  /// On web, image OCR is not supported by the current ML Kit setup.
  bool get imageOcrSupported => !kIsWeb;
}
