import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

/// Firestore-backed settings for the legal assistant.
///
/// Document: `app_settings/legal_assistant`
/// Fields:
/// - `enabled` (bool, default true)
/// - `extractionApiUrl` (String?) — HTTPS endpoint; POST JSON `{"text":"..."}` returns mergeable fields
/// - `autoCreateWithoutConfirm` (bool, default false) — org-wide: schedule immediately when date parsed
///
/// Optional user override on `users/{uid}`:
/// - `legalAssistantAutoCreate` (bool?) — if non-null, overrides org `autoCreateWithoutConfirm` for that user
/// - `legalAssistantDisabled` (bool) — if true, user cannot use the feature (default false)
class LegalAssistantSettings {
  final bool enabled;
  final String? extractionApiUrl;
  final bool autoCreateWithoutConfirm;

  const LegalAssistantSettings({
    required this.enabled,
    this.extractionApiUrl,
    required this.autoCreateWithoutConfirm,
  });

  static const LegalAssistantSettings defaults = LegalAssistantSettings(
    enabled: true,
    extractionApiUrl: null,
    autoCreateWithoutConfirm: false,
  );
}

class LegalAssistantSettingsService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;

  Future<LegalAssistantSettings> loadAppSettings() async {
    try {
      final doc =
          await _firestore.collection('app_settings').doc('legal_assistant').get();
      if (!doc.exists || doc.data() == null) {
        return LegalAssistantSettings.defaults;
      }
      final m = doc.data()!;
      String? apiUrl;
      final rawUrl = m['extractionApiUrl'];
      if (rawUrl is String && rawUrl.trim().isNotEmpty) {
        apiUrl = rawUrl.trim();
      }
      return LegalAssistantSettings(
        enabled: m['enabled'] as bool? ?? true,
        extractionApiUrl: apiUrl,
        autoCreateWithoutConfirm:
            m['autoCreateWithoutConfirm'] as bool? ?? false,
      );
    } catch (_) {
      return LegalAssistantSettings.defaults;
    }
  }

  /// Effective auto-create: user override ?? org setting.
  Future<bool> effectiveAutoCreateWithoutConfirm() async {
    final user = _auth.currentUser;
    final app = await loadAppSettings();
    if (user == null) return app.autoCreateWithoutConfirm;
    try {
      final u = await _firestore.collection('users').doc(user.uid).get();
      final data = u.data();
      if (data == null) return app.autoCreateWithoutConfirm;
      if (data['legalAssistantAutoCreate'] is bool) {
        return data['legalAssistantAutoCreate'] as bool;
      }
    } catch (_) {}
    return app.autoCreateWithoutConfirm;
  }

  Future<bool> isUserBlocked() async {
    final user = _auth.currentUser;
    if (user == null) return true;
    try {
      final u = await _firestore.collection('users').doc(user.uid).get();
      return u.data()?['legalAssistantDisabled'] == true;
    } catch (_) {
      return false;
    }
  }

  Future<bool> canUseFeature() async {
    final app = await loadAppSettings();
    if (!app.enabled) return false;
    if (await isUserBlocked()) return false;
    final user = _auth.currentUser;
    if (user == null) return false;
    final doc = await _firestore.collection('users').doc(user.uid).get();
    final role = doc.data()?['role'] as String? ?? '';
    return role == 'staff' || role == 'attorney' || role == 'admin';
  }
}
