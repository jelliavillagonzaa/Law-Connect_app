import 'dart:convert';

import 'package:http/http.dart' as http;

import '../models/court_message_extraction.dart';

/// Optional server / automation hook: POST JSON `{"text":"..."}` and merge known fields.
class LegalAssistantCloudParser {
  Future<CourtMessageExtraction?> tryEnhance({
    required String url,
    required String text,
    required CourtMessageExtraction baseline,
  }) async {
    try {
      final uri = Uri.parse(url);
      final resp = await http
          .post(
            uri,
            headers: const {'Content-Type': 'application/json'},
            body: jsonEncode({'text': text}),
          )
          .timeout(const Duration(seconds: 25));
      if (resp.statusCode < 200 || resp.statusCode >= 300) return null;
      final map = jsonDecode(resp.body);
      if (map is! Map<String, dynamic>) return null;
      return _merge(baseline, map);
    } catch (_) {
      return null;
    }
  }

  CourtMessageExtraction _merge(
    CourtMessageExtraction b,
    Map<String, dynamic> m,
  ) {
    DateTime? dt;
    final iso = m['hearingDateTime'] ?? m['hearing_date_time'];
    if (iso is String) {
      dt = DateTime.tryParse(iso);
    }
    String? s(String? k) {
      final v = m[k];
      return v is String && v.trim().isNotEmpty ? v.trim() : null;
    }

    return b.copyWith(
      hearingDateTime: dt ?? b.hearingDateTime,
      courtName: s('courtName') ?? s('court') ?? b.courtName,
      judge: s('judge') ?? b.judge,
      caseNumber: s('caseNumber') ?? s('case_number') ?? b.caseNumber,
      plaintiff: s('plaintiff') ?? b.plaintiff,
      defendant: s('defendant') ?? b.defendant,
      attorneyMentioned: s('attorney') ?? s('attorneyMentioned') ?? b.attorneyMentioned,
      clientMentioned: s('client') ?? s('clientMentioned') ?? b.clientMentioned,
      roomOrBranch: s('room') ?? s('roomOrBranch') ?? b.roomOrBranch,
      summaryNotes: s('summary') ?? s('summaryNotes') ?? b.summaryNotes,
    );
  }
}
