import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:intl/intl.dart';
import '../../theme/app_theme.dart';

class AttorneyRemindersScreen extends StatefulWidget {
  const AttorneyRemindersScreen({super.key});

  @override
  State<AttorneyRemindersScreen> createState() =>
      _AttorneyRemindersScreenState();
}

class _AttorneyRemindersScreenState extends State<AttorneyRemindersScreen> {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;

  Stream<List<QueryDocumentSnapshot>> _getRemindersStream() {
    final userId = _auth.currentUser?.uid;
    if (userId == null) {
      return Stream.value([]);
    }

    // Use a simple query to avoid composite index requirement
    // Query by userId only, then filter by type and sort in memory
    return _firestore
        .collection('notifications')
        .where('userId', isEqualTo: userId)
        .limit(200)
        .snapshots()
        .map((snapshot) {
          // Filter by type in memory
          final filtered = snapshot.docs.where((doc) {
            final data = doc.data();
            final type = data['type'] as String? ?? '';
            return type == 'appointment_scheduled' ||
                type == 'appointment_3day_reminder' ||
                type == 'appointment_sameday_reminder';
          }).toList();

          // Sort by createdAt in memory (descending)
          filtered.sort((a, b) {
            final aCreatedAt = a.data()['createdAt'] as Timestamp?;
            final bCreatedAt = b.data()['createdAt'] as Timestamp?;
            if (aCreatedAt == null && bCreatedAt == null) return 0;
            if (aCreatedAt == null) return 1;
            if (bCreatedAt == null) return -1;
            return bCreatedAt.compareTo(aCreatedAt); // Descending
          });

          return filtered;
        });
  }

  Future<void> _markAsRead(String notificationId) async {
    try {
      await _firestore.collection('notifications').doc(notificationId).update({
        'isRead': true,
        'readAt': FieldValue.serverTimestamp(),
      });
    } catch (e) {
      print('Error marking notification as read: $e');
    }
  }

  Future<void> _markAllAsRead() async {
    final userId = _auth.currentUser?.uid;
    if (userId == null) return;

    try {
      // Get all notifications for user, then filter by type in memory
      final query = await _firestore
          .collection('notifications')
          .where('userId', isEqualTo: userId)
          .where('isRead', isEqualTo: false)
          .limit(200)
          .get();

      // Filter by appointment reminder types
      final appointmentReminders = query.docs.where((doc) {
        final data = doc.data();
        final type = data['type'] as String? ?? '';
        return type == 'appointment_scheduled' ||
            type == 'appointment_3day_reminder' ||
            type == 'appointment_sameday_reminder';
      }).toList();

      final batch = _firestore.batch();
      for (final doc in appointmentReminders) {
        batch.update(doc.reference, {
          'isRead': true,
          'readAt': FieldValue.serverTimestamp(),
        });
      }
      if (appointmentReminders.isNotEmpty) {
        await batch.commit();
      }
    } catch (e) {
      print('Error marking all as read: $e');
    }
  }

  String _getReminderIcon(String type) {
    switch (type) {
      case 'appointment_scheduled':
        return '📅';
      case 'appointment_3day_reminder':
        return '⏰';
      case 'appointment_sameday_reminder':
        return '🔔';
      default:
        return '📌';
    }
  }

  Color _getReminderColor(String type) {
    switch (type) {
      case 'appointment_scheduled':
        return Colors.blue;
      case 'appointment_3day_reminder':
        return Colors.orange;
      case 'appointment_sameday_reminder':
        return Colors.red;
      default:
        return Colors.grey;
    }
  }

  String _getReminderTitle(String type) {
    switch (type) {
      case 'appointment_scheduled':
        return 'Appointment Scheduled';
      case 'appointment_3day_reminder':
        return '3-Day Reminder';
      case 'appointment_sameday_reminder':
        return 'Same-Day Reminder';
      default:
        return 'Reminder';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF4F4F4),
      appBar: AppBar(
        title: const Text('Appointment Reminders'),
        backgroundColor: AppTheme.royalBlue,
        iconTheme: const IconThemeData(color: Colors.white),
        actions: [
          StreamBuilder<List<QueryDocumentSnapshot>>(
            stream: _getRemindersStream(),
            builder: (context, snapshot) {
              if (!snapshot.hasData) {
                return const SizedBox.shrink();
              }

              final unreadCount = snapshot.data!
                  .where(
                    (doc) =>
                        (doc.data() as Map<String, dynamic>)['isRead'] != true,
                  )
                  .length;

              if (unreadCount == 0) {
                return const SizedBox.shrink();
              }

              return TextButton.icon(
                onPressed: _markAllAsRead,
                icon: const Icon(Icons.done_all, color: Colors.white, size: 18),
                label: Text(
                  'Mark all read ($unreadCount)',
                  style: const TextStyle(color: Colors.white, fontSize: 12),
                ),
              );
            },
          ),
        ],
      ),
      body: StreamBuilder<List<QueryDocumentSnapshot>>(
        stream: _getRemindersStream(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          if (snapshot.hasError) {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.error_outline, size: 64, color: Colors.red),
                  const SizedBox(height: 16),
                  Text(
                    'Error loading reminders: ${snapshot.error}',
                    textAlign: TextAlign.center,
                    style: const TextStyle(fontSize: 16, color: Colors.red),
                  ),
                ],
              ),
            );
          }

          final docs = snapshot.data ?? [];

          if (docs.isEmpty) {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.notifications_none,
                    size: 64,
                    color: Colors.grey[400],
                  ),
                  const SizedBox(height: 16),
                  Text(
                    'No Reminders',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w600,
                      color: Colors.grey[600],
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'All appointment reminders will appear here',
                    style: TextStyle(fontSize: 14, color: Colors.grey[500]),
                  ),
                ],
              ),
            );
          }

          return ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: docs.length,
            itemBuilder: (context, index) {
              final doc = docs[index];
              final data = doc.data() as Map<String, dynamic>;
              final type = data['type'] as String? ?? '';
              final title = data['title'] as String? ?? _getReminderTitle(type);
              final message = data['message'] as String? ?? '';
              final createdAt = (data['createdAt'] as Timestamp?)?.toDate();
              final isRead = data['isRead'] as bool? ?? false;

              return Card(
                margin: const EdgeInsets.only(bottom: 12),
                elevation: isRead ? 1 : 3,
                color: isRead ? Colors.white : Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                  side: BorderSide(
                    color: isRead
                        ? Colors.transparent
                        : _getReminderColor(type),
                    width: isRead ? 0 : 2,
                  ),
                ),
                child: InkWell(
                  onTap: () {
                    if (!isRead) {
                      _markAsRead(doc.id);
                    }
                  },
                  borderRadius: BorderRadius.circular(12),
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // Icon
                        Container(
                          width: 48,
                          height: 48,
                          decoration: BoxDecoration(
                            color: _getReminderColor(type).withOpacity(0.1),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Center(
                            child: Text(
                              _getReminderIcon(type),
                              style: const TextStyle(fontSize: 24),
                            ),
                          ),
                        ),
                        const SizedBox(width: 12),
                        // Content
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Expanded(
                                    child: Text(
                                      title,
                                      style: TextStyle(
                                        fontSize: 16,
                                        fontWeight: FontWeight.w600,
                                        color: isRead
                                            ? Colors.grey[700]
                                            : Colors.black87,
                                      ),
                                    ),
                                  ),
                                  if (!isRead)
                                    Container(
                                      width: 8,
                                      height: 8,
                                      decoration: BoxDecoration(
                                        color: _getReminderColor(type),
                                        shape: BoxShape.circle,
                                      ),
                                    ),
                                ],
                              ),
                              const SizedBox(height: 4),
                              Text(
                                message,
                                style: TextStyle(
                                  fontSize: 14,
                                  color: isRead
                                      ? Colors.grey[600]
                                      : Colors.black87,
                                ),
                              ),
                              if (createdAt != null) ...[
                                const SizedBox(height: 8),
                                Text(
                                  DateFormat(
                                    'MMM dd, yyyy • hh:mm a',
                                  ).format(createdAt),
                                  style: TextStyle(
                                    fontSize: 12,
                                    color: Colors.grey[500],
                                  ),
                                ),
                              ],
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
