import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../../services/court_email_queue_service.dart';
import '../../services/staff_auth_service.dart';
import '../../theme/app_theme.dart';

class AICalendarQueueScreen extends StatefulWidget {
  const AICalendarQueueScreen({super.key});

  @override
  State<AICalendarQueueScreen> createState() => _AICalendarQueueScreenState();
}

class _AICalendarQueueScreenState extends State<AICalendarQueueScreen> {
  final CourtEmailQueueService _queueService = CourtEmailQueueService();
  final StaffAuthService _staffAuthService = StaffAuthService();

  String? _assignedAttorneyId;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _initViewer();
  }

  Future<void> _initViewer() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) {
      if (mounted) setState(() => _loading = false);
      return;
    }

    // Staff: assigned attorney comes from StaffAuthService (primary),
    // but also support staff stored in `users` (fallback).
    final staff = await _staffAuthService.getCurrentStaff();
    if (staff != null) {
      setState(() {
        _assignedAttorneyId = staff.assignedAttorneyId;
        _loading = false;
      });
      return;
    }

    // Attorney/admin: assigned attorney = my uid for attorney; admin sees all.
    final userDoc =
        await FirebaseFirestore.instance.collection('users').doc(user.uid).get();
    final role = userDoc.data()?['role'] as String? ?? '';
    if (role == 'attorney') {
      setState(() {
        _assignedAttorneyId = user.uid;
        _loading = false;
      });
      return;
    }

    if (role == 'staff') {
      final aid = userDoc.data()?['assignedAttorneyId'] as String?;
      setState(() {
        _assignedAttorneyId = aid;
        _loading = false;
      });
      return;
    }

    setState(() {
      _assignedAttorneyId = null; // null => show all pending for admin
      _loading = false;
    });
  }

  Future<void> _onAction({
    required String docId,
    required String action,
    String? titlePrefix,
  }) async {
    try {
      await _queueService.processQueueItem(
        docId: docId,
        action: action,
        titlePrefix: titlePrefix,
      );
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Updated successfully')),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed: $e')),
      );
    }
  }

  DateTime? _parseHearingDateTime(dynamic extraction) {
    if (extraction is Map) {
      final val = extraction['hearingDateTime'];
      if (val is String) {
        return DateTime.tryParse(val);
      }
    }
    return null;
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return Scaffold(
        appBar: AppBar(title: const Text('AI Calendar')),
        body: const Center(child: CircularProgressIndicator()),
      );
    }

    final user = FirebaseAuth.instance.currentUser;
    if (user == null) {
      return const Scaffold(
        body: Center(child: Text('Please sign in')),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('AI Calendar (Court Email Queue)'),
        backgroundColor: AppTheme.royalBlue,
      ),
      body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: FirebaseFirestore.instance
            .collection('court_email_queue')
            .where('status', isEqualTo: 'pending_review')
            .limit(100)
            .snapshots(),
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            final err = snapshot.error;
            if (kDebugMode) {
              debugPrint('court_email_queue stream error: $err');
            }
            final message = err is FirebaseException
                ? '${err.code}: ${err.message ?? err.toString()}'
                : err.toString();
            return Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Icon(Icons.error_outline, size: 48, color: Colors.redAccent),
                    const SizedBox(height: 16),
                    const Text(
                      'Failed to load queue',
                      style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                    ),
                    const SizedBox(height: 12),
                    SelectableText(
                      message,
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 13, color: Colors.grey.shade800),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'If this says permission-denied, deploy the latest firestore.rules '
                      'or ask an admin to confirm your user role in Firestore.',
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 12, color: Colors.grey.shade600),
                    ),
                  ],
                ),
              ),
            );
          }
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }

          var docs = snapshot.data!.docs;
          if (_assignedAttorneyId != null) {
            docs = docs.where((d) {
              final data = d.data();
              return data['assignedTo'] == _assignedAttorneyId;
            }).toList();
          }

          if (docs.isEmpty) {
            return const Center(child: Text('No pending AI queue items.'));
          }

          docs.sort((a, b) {
            final aa = a.data()['receivedAt'] as Timestamp?;
            final bb = b.data()['receivedAt'] as Timestamp?;
            return (bb?.toDate() ?? DateTime.fromMillisecondsSinceEpoch(0))
                .compareTo(aa?.toDate() ?? DateTime.fromMillisecondsSinceEpoch(0));
          });

          return ListView.separated(
            padding: const EdgeInsets.all(16),
            itemCount: docs.length,
            separatorBuilder: (_, __) => const SizedBox(height: 12),
            itemBuilder: (context, idx) {
              final doc = docs[idx];
              final data = doc.data();
              final from = data['from'] as String? ?? '';
              final subject = data['subject'] as String? ?? '';
              final confidence = data['confidence']?.toString() ?? 'low';
              final extraction = data['extraction'];
              final hearingDt = _parseHearingDateTime(extraction);

              final caseNumber = (extraction is Map)
                  ? extraction['caseNumber']?.toString()
                  : null;

              final title = [
                'Hearing',
                if (caseNumber != null && caseNumber.trim().isNotEmpty)
                  '(${caseNumber.trim()})',
              ].join(' ');

              final whenStr = hearingDt != null
                  ? DateFormat('EEE, MMM d, yyyy • hh:mm a').format(hearingDt)
                  : 'Date/time missing';

              return Card(
                elevation: 0,
                shape: RoundedRectangleBorder(
                  side: BorderSide(color: Colors.grey.shade300),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        title,
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 16,
                        ),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        whenStr,
                        style: TextStyle(color: Colors.grey.shade700),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'From: ${from.isEmpty ? 'court' : from}\nSubject: $subject',
                        style: const TextStyle(fontSize: 13),
                      ),
                      const SizedBox(height: 10),
                      Row(
                        children: [
                          Chip(
                            label: Text('Confidence: $confidence'),
                            backgroundColor: Colors.blue.shade50,
                          ),
                          const Spacer(),
                        ],
                      ),
                      const SizedBox(height: 12),
                      Row(
                        children: [
                          Expanded(
                            child: ElevatedButton.icon(
                              icon: const Icon(Icons.check_circle_outline),
                              style: ElevatedButton.styleFrom(
                                backgroundColor: AppTheme.gold,
                                foregroundColor: Colors.white,
                              ),
                              onPressed: () => _onAction(
                                docId: doc.id,
                                action: 'schedule',
                                titlePrefix: '[AI]',
                              ),
                              label: const Text('Add to calendar'),
                            ),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: OutlinedButton.icon(
                              icon: const Icon(Icons.block_outlined),
                              onPressed: () => _onAction(
                                docId: doc.id,
                                action: 'ignore',
                              ),
                              label: const Text('Ignore'),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}

