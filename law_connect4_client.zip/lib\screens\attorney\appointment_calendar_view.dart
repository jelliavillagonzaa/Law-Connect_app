import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../../models/appointment_model.dart';
import '../../services/enhanced_appointment_service.dart';
import '../../services/auth_service.dart';
import 'appointment_scheduler_form.dart';

class AppointmentCalendarView extends StatefulWidget {
  const AppointmentCalendarView({super.key});

  @override
  State<AppointmentCalendarView> createState() =>
      _AppointmentCalendarViewState();
}

class _AppointmentCalendarViewState extends State<AppointmentCalendarView> {
  final EnhancedAppointmentService _appointmentService =
      EnhancedAppointmentService();
  final AuthService _authService = AuthService();
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  DateTime _viewDate = DateTime.now();
  String _viewMode = 'month'; // 'month' or 'week'
  List<AppointmentModel> _appointments = [];
  final Map<String, String> _clientNameCache =
      <String, String>{}; // Cache for client full names
  final Map<String, String> _clientEmailCache =
      <String, String>{}; // Cache for client emails
  bool _isLoading = true;

  // Calendar color theme (match reference UI: blue + gold, Sunday red)
  static const Color calendarBlue = Color.fromARGB(255, 46, 109, 192);
  static const Color calendarGold = Color(0xFFF4C10F);
  static const Color sundayRed = Color(0xFFE53935);
  // Accent color for appointment pills (reuse calendar blue by default)
  static const Color primaryRed = calendarBlue;

  @override
  void initState() {
    super.initState();
    _loadAppointments();
  }

  void _loadAppointments() {
    final user = _authService.currentUser;
    if (user == null) {
      setState(() => _isLoading = false);
      return;
    }

    setState(() {
      _isLoading = true;
    });

    _appointmentService.getAttorneyAppointments(user.uid).listen((
      appointments,
    ) {
      if (mounted) {
        setState(() {
          _appointments = appointments;
        });
        // Load full client names for all appointments
        _loadClientNames(appointments);
        setState(() {
          _isLoading = false;
        });
      }
    });
  }

  /// Get the client name cache (always returns a valid map)
  Map<String, String> _getClientNameCache() {
    return _clientNameCache;
  }

  /// Get the client email cache (always returns a valid map)
  Map<String, String> _getClientEmailCache() {
    try {
      return _clientEmailCache;
    } catch (e) {
      // If cache is somehow undefined, return empty map
      return <String, String>{};
    }
  }

  /// Get client email from cache or profile
  String _getClientEmail(AppointmentModel appointment) {
    if (appointment.clientId.isEmpty) {
      return '';
    }

    try {
      final cache = _getClientEmailCache();
      if (cache.isNotEmpty) {
        final cachedEmail = cache[appointment.clientId];
        if (cachedEmail != null && cachedEmail.isNotEmpty) {
          return cachedEmail;
        }
      }
    } catch (e) {
      // If cache access fails, fall through
      print('Error accessing email cache: $e');
    }

    // Trigger async fetch if not cached (non-blocking)
    try {
      _loadClientNames([appointment]);
    } catch (e) {
      print('Error triggering email fetch: $e');
    }

    return '';
  }

  /// Load full client names from client profiles
  Future<void> _loadClientNames(List<AppointmentModel> appointments) async {
    final clientIds = appointments
        .map((apt) => apt.clientId)
        .where((id) => id.isNotEmpty)
        .toSet()
        .toList();

    // Filter out already cached client IDs - use safe access
    final uncachedClientIds = <String>[];
    for (final id in clientIds) {
      try {
        final cache = _getClientNameCache();
        if (!cache.containsKey(id)) {
          uncachedClientIds.add(id);
        }
      } catch (e) {
        // If cache access fails, include ID to fetch
        uncachedClientIds.add(id);
      }
    }

    if (uncachedClientIds.isEmpty) {
      return; // All names already cached
    }

    // Fetch client names in parallel for better performance
    final futures = uncachedClientIds.map((clientId) async {
      try {
        final clientDoc = await _firestore
            .collection('users')
            .doc(clientId)
            .get();

        if (clientDoc.exists) {
          final clientData = clientDoc.data()!;
          // Try multiple possible field names for full name
          // Priority: fullName > full_name > name
          final fullName =
              clientData['fullName'] as String? ??
              clientData['full_name'] as String? ??
              '';
          final name = clientData['name'] as String? ?? '';
          final email = clientData['email'] as String? ?? '';

          // Build display name: prefer fullName, fallback to name
          // Never use email - always get from profile
          String displayName = '';
          if (fullName.isNotEmpty && fullName.trim().isNotEmpty) {
            displayName = fullName.trim();
          } else if (name.isNotEmpty && name.trim().isNotEmpty) {
            displayName = name.trim();
          }

          // Return both name and email
          return {
            'clientId': clientId,
            'displayName': displayName.isNotEmpty && !displayName.contains('@')
                ? displayName
                : '',
            'email': email.isNotEmpty ? email : '',
          };
        }
      } catch (e) {
        print('Error loading client name for $clientId: $e');
        // Return empty for failed requests
      }
      return null;
    }).toList();

    // Wait for all requests to complete
    final results = await Future.wait(futures);

    // Update cache with all results at once
    if (mounted) {
      try {
        setState(() {
          final nameCache = _getClientNameCache();
          final emailCache = _getClientEmailCache();
          for (final result in results) {
            if (result != null) {
              final clientId = result['clientId'];
              if (clientId != null) {
                // Cache name if available
                final displayName = result['displayName'];
                if (displayName != null) {
                  // Only cache valid names (not emails)
                  final displayNameStr = displayName.toString();
                  if (displayNameStr.isNotEmpty &&
                      !_isEmailAddress(displayNameStr)) {
                    nameCache[clientId.toString()] = displayNameStr;
                  }
                }

                // Cache email if available
                final email = result['email'];
                if (email != null) {
                  final emailStr = email.toString();
                  if (emailStr.isNotEmpty) {
                    emailCache[clientId.toString()] = emailStr;
                  }
                }
              }
            }
          }
        });
      } catch (e) {
        print('Error updating client caches: $e');
      }
    }
  }

  /// Get the full client name from profile, never show email
  String _getClientDisplayName(AppointmentModel appointment) {
    // Ensure clientId is valid
    if (appointment.clientId.isEmpty) {
      final storedName = appointment.clientName;
      // Never show email addresses - check if it looks like an email
      if (storedName.isNotEmpty && !_isEmailAddress(storedName)) {
        return storedName;
      }
      return 'Client';
    }

    // First, try to get from cache (full name from profile)
    try {
      final cache = _getClientNameCache();
      final cachedName = cache[appointment.clientId];
      if (cachedName != null &&
          cachedName.isNotEmpty &&
          !_isEmailAddress(cachedName)) {
        return cachedName;
      }
    } catch (e) {
      // If cache access fails, fall through
    }

    // Check stored name - only use if it's not an email
    final storedName = appointment.clientName;
    if (storedName.isNotEmpty &&
        !_isEmailAddress(storedName) &&
        storedName.length > 2) {
      // If stored name looks like a real name (not email), use it temporarily
      return storedName;
    }

    // Trigger async fetch for names that might not be loaded yet
    _loadClientNames([appointment]);

    // Return a generic placeholder while loading from profile
    return 'Client';
  }

  /// Check if a string looks like an email address
  bool _isEmailAddress(String text) {
    // Simple email pattern check
    return text.contains('@') &&
        text.contains('.') &&
        text.indexOf('@') < text.lastIndexOf('.') &&
        text.length > 5; // Minimum email length
  }

  List<AppointmentModel> _getAppointmentsForDate(DateTime date) {
    return _appointments.where((apt) {
      final aptDate = DateTime(
        apt.appointmentDateTime.year,
        apt.appointmentDateTime.month,
        apt.appointmentDateTime.day,
      );
      final checkDate = DateTime(date.year, date.month, date.day);
      return aptDate == checkDate;
    }).toList();
  }

  Color _getAppointmentColor(AppointmentModel appointment) {
    switch (appointment.status) {
      case 'scheduled':
        return primaryRed;
      case 'completed':
        return Colors.green;
      case 'cancelled':
        return Colors.grey;
      case 'rescheduled':
        return Colors.orange;
      default:
        return primaryRed;
    }
  }

  Future<void> _createAppointmentForDate(DateTime date) async {
    final result = await showDialog<bool>(
      context: context,
      builder: (context) => Dialog(
        child: Container(
          width: 500,
          padding: const EdgeInsets.all(24),
          child: AppointmentSchedulerForm(
            // Pre-select the date
          ),
        ),
      ),
    );

    if (result == true) {
      _loadAppointments();
    }
  }

  @override
  Widget build(BuildContext context) {
    final isMobile = MediaQuery.of(context).size.width < 800;

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: calendarBlue,
        title: const Text(
          'Appointment Calendar',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
        iconTheme: const IconThemeData(color: Colors.white),
        elevation: 0,
        actions: [
          // View Mode Toggle - Desktop only
          if (!isMobile)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8),
              child: ToggleButtons(
                isSelected: [_viewMode == 'month', _viewMode == 'week'],
                onPressed: (index) {
                  setState(() {
                    _viewMode = index == 0 ? 'month' : 'week';
                  });
                },
                borderRadius: BorderRadius.circular(8),
                selectedColor: Colors.white,
                fillColor: Colors.white.withOpacity(0.2),
                color: Colors.white70,
                children: const [
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    child: Text('Month'),
                  ),
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    child: Text('Week'),
                  ),
                ],
              ),
            ),
          IconButton(
            icon: const Icon(Icons.add, color: Colors.white),
            onPressed: () async {
              final result = await Navigator.push<bool>(
                context,
                MaterialPageRoute(
                  builder: (context) => const AppointmentSchedulerForm(),
                ),
              );
              if (result == true) {
                _loadAppointments();
              }
            },
            tooltip: 'New Appointment',
          ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: [
                // Calendar Header & month/year bar
                _buildCalendarHeader(isMobile: isMobile),
                // Weekday labels row
                _buildWeekdayRow(isMobile: isMobile),
                // Calendar Grid - Mobile always shows month view
                Expanded(
                  child: (isMobile || _viewMode == 'month')
                      ? _buildMonthView()
                      : _buildWeekView(),
                ),
              ],
            ),
    );
  }

  Widget _buildCalendarHeader({required bool isMobile}) {
    return Container(
      padding: EdgeInsets.all(isMobile ? 12 : 16),
      color: calendarBlue,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          IconButton(
            icon: const Icon(Icons.chevron_left, color: Colors.white),
            onPressed: () {
              setState(() {
                _viewDate = _viewMode == 'month' || isMobile
                    ? DateTime(_viewDate.year, _viewDate.month - 1)
                    : _viewDate.subtract(const Duration(days: 7));
              });
            },
          ),
          Flexible(
            child: Text(
              _viewMode == 'month' || isMobile
                  ? DateFormat('MMMM yyyy').format(_viewDate)
                  : 'Week of ${DateFormat('MMM dd').format(_viewDate)}',
              style: TextStyle(
                fontSize: isMobile ? 18 : 22,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
              textAlign: TextAlign.center,
            ),
          ),
          Row(
            children: [
              Container(
                padding: EdgeInsets.symmetric(
                  horizontal: isMobile ? 10 : 14,
                  vertical: 6,
                ),
                decoration: BoxDecoration(
                  color: calendarGold,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  DateFormat('yyyy').format(_viewDate),
                  style: TextStyle(
                    fontSize: isMobile ? 14 : 16,
                    fontWeight: FontWeight.w700,
                    color: Colors.black87,
                  ),
                ),
              ),
              IconButton(
                icon: const Icon(Icons.chevron_right, color: Colors.white),
                onPressed: () {
                  setState(() {
                    _viewDate = _viewMode == 'month' || isMobile
                        ? DateTime(_viewDate.year, _viewDate.month + 1)
                        : _viewDate.add(const Duration(days: 7));
                  });
                },
              ),
            ],
          ),
          if (!isMobile)
            TextButton(
              onPressed: () {
                setState(() {
                  _viewDate = DateTime.now();
                });
              },
              child: const Text('Today'),
            ),
        ],
      ),
    );
  }

  Widget _buildWeekdayRow({required bool isMobile}) {
    const labels = ['S', 'M', 'T', 'W', 'T', 'F', 'S'];
    return Container(
      color: Colors.white,
      padding: EdgeInsets.symmetric(
        horizontal: 16,
        vertical: isMobile ? 8 : 10,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: List.generate(labels.length, (index) {
          final isSunday = index == 0 || index == 6;
          return Expanded(
            child: Center(
              child: Text(
                labels[index],
                style: TextStyle(
                  fontSize: 12, // same size for mobile and web
                  fontWeight: FontWeight.w600,
                  color: isSunday ? sundayRed : Colors.grey[700],
                ),
              ),
            ),
          );
        }),
      ),
    );
  }

  Widget _buildMonthView() {
    final firstDayOfMonth = DateTime(_viewDate.year, _viewDate.month, 1);
    final lastDayOfMonth = DateTime(_viewDate.year, _viewDate.month + 1, 0);
    final firstDayWeekday = firstDayOfMonth.weekday;
    final daysInMonth = lastDayOfMonth.day;

    // Get all days to display (including previous/next month days)
    final List<DateTime> days = [];
    // Previous month days
    for (int i = firstDayWeekday - 1; i > 0; i--) {
      days.add(firstDayOfMonth.subtract(Duration(days: i)));
    }
    // Current month days
    for (int i = 1; i <= daysInMonth; i++) {
      days.add(DateTime(_viewDate.year, _viewDate.month, i));
    }
    // Next month days to fill the grid
    final remainingDays = 42 - days.length; // 6 weeks * 7 days
    for (int i = 1; i <= remainingDays; i++) {
      days.add(DateTime(_viewDate.year, _viewDate.month + 1, i));
    }

    // Adjust cell size for web vs mobile – on web we use a more compact grid
    final screenWidth = MediaQuery.of(context).size.width;
    final isWeb = screenWidth > 200;
    final gridPadding = EdgeInsets.all(isWeb ? 8 : 16);
    final spacing = isWeb ? 4.0 : 8.0;
    final aspectRatio = isWeb ? 0.9 : 1.2;

    return GridView.builder(
      padding: gridPadding,
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 7,
        childAspectRatio: aspectRatio,
        crossAxisSpacing: spacing,
        mainAxisSpacing: spacing,
      ),
      itemCount: days.length,
      itemBuilder: (context, index) {
        final day = days[index];
        final isCurrentMonth = day.month == _viewDate.month;
        final isToday =
            day.year == DateTime.now().year &&
            day.month == DateTime.now().month &&
            day.day == DateTime.now().day;
        final dayAppointments = _getAppointmentsForDate(day);

        return _buildDayCell(day, isCurrentMonth, isToday, dayAppointments);
      },
    );
  }

  Widget _buildWeekView() {
    final startOfWeek = _viewDate.subtract(
      Duration(days: _viewDate.weekday - 1),
    );
    final weekDays = List.generate(
      7,
      (i) => startOfWeek.add(Duration(days: i)),
    );

    return Row(
      children: weekDays
          .map((day) => Expanded(child: _buildWeekDayColumn(day)))
          .toList(),
    );
  }

  Widget _buildWeekDayColumn(DateTime day) {
    final isToday =
        day.year == DateTime.now().year &&
        day.month == DateTime.now().month &&
        day.day == DateTime.now().day;
    final dayAppointments = _getAppointmentsForDate(day);

    return Container(
      margin: const EdgeInsets.all(4),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.96),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(
          color: isToday ? calendarBlue : Colors.grey[300]!,
          width: isToday ? 2 : 1,
        ),
      ),
      child: Column(
        children: [
          // Day Header - tappable if has appointments
          InkWell(
            onTap: dayAppointments.isNotEmpty
                ? () => _showAppointmentsForDate(day, dayAppointments)
                : () => _createAppointmentForDate(day),
            child: Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: isToday
                    ? calendarBlue.withOpacity(0.08)
                    : Colors.grey[50],
                borderRadius: const BorderRadius.only(
                  topLeft: Radius.circular(8),
                  topRight: Radius.circular(8),
                ),
              ),
              child: Column(
                children: [
                  Text(
                    DateFormat('EEE').format(day),
                    style: TextStyle(
                      fontSize: 12,
                      color: Colors.grey[600],
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        '${day.day}',
                        style: TextStyle(
                          fontSize: 10,
                          fontWeight: FontWeight.bold,
                          color: isToday ? calendarBlue : Colors.black87,
                        ),
                      ),
                      if (dayAppointments.isNotEmpty) ...[
                        const SizedBox(width: 4),
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 5,
                            vertical: 1,
                          ),
                          decoration: BoxDecoration(
                            color: calendarBlue,
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Text(
                            '${dayAppointments.length}',
                            style: const TextStyle(
                              fontSize: 8,
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ],
                    ],
                  ),
                ],
              ),
            ),
          ),
          // Appointments
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.all(4),
              itemCount: dayAppointments.length,
              itemBuilder: (context, index) {
                final apt = dayAppointments[index];
                return _buildTimeSlotAppointment(apt);
              },
            ),
          ),
          // Add button
          InkWell(
            onTap: () => _createAppointmentForDate(day),
            child: Container(
              padding: const EdgeInsets.all(8),
              child: Icon(Icons.add, size: 20, color: Colors.grey[600]),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDayCell(
    DateTime day,
    bool isCurrentMonth,
    bool isToday,
    List<AppointmentModel> appointments,
  ) {
    return Container(
      decoration: BoxDecoration(
        color: isToday
            ? calendarBlue.withOpacity(0.08)
            : Colors.white.withOpacity(0.96),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(
          color: isToday ? calendarBlue : Colors.grey[300]!,
          width: isToday ? 2 : 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Date number - tappable if has appointments
          InkWell(
            onTap: appointments.isNotEmpty
                ? () => _showAppointmentsForDate(day, appointments)
                : () => _createAppointmentForDate(day),
            child: Padding(
              padding: const EdgeInsets.all(8),
              child: Row(
                children: [
                  Text(
                    '${day.day}',
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: isToday ? FontWeight.w600 : FontWeight.normal,
                      color: isCurrentMonth
                          ? (isToday
                                ? calendarBlue
                                : (day.weekday == DateTime.sunday
                                      ? sundayRed
                                      : Colors.black87))
                          : Colors.grey[400],
                    ),
                  ),
                  if (appointments.isNotEmpty) ...[
                    const SizedBox(width: 4),
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 6,
                        vertical: 2,
                      ),
                      decoration: BoxDecoration(
                        color: calendarBlue,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Text(
                        '${appointments.length}',
                        style: const TextStyle(
                          fontSize: 9,
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ),
          // Appointments list - show more names
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.symmetric(horizontal: 4),
              itemCount: appointments.length > 3 ? 3 : appointments.length,
              itemBuilder: (context, index) {
                final apt = appointments[index];
                return InkWell(
                  onTap: () => _showAppointmentDetails(apt),
                  child: Container(
                    margin: const EdgeInsets.only(bottom: 2),
                    padding: const EdgeInsets.symmetric(
                      horizontal: 4,
                      vertical: 2,
                    ),
                    decoration: BoxDecoration(
                      color: _getAppointmentColor(apt),
                      borderRadius: BorderRadius.circular(4),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          DateFormat('hh:mm a').format(apt.appointmentDateTime),
                          style: const TextStyle(
                            fontSize: 8,
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Text(
                          _getClientDisplayName(apt),
                          style: const TextStyle(
                            fontSize: 9,
                            color: Colors.white,
                            fontWeight: FontWeight.w500,
                          ),
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
          if (appointments.length > 3)
            Padding(
              padding: const EdgeInsets.all(4),
              child: Text(
                '+${appointments.length - 3} more',
                style: TextStyle(fontSize: 10, color: Colors.grey[600]),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildTimeSlotAppointment(AppointmentModel appointment) {
    return InkWell(
      onTap: () => _showAppointmentDetails(appointment),
      child: Container(
        margin: const EdgeInsets.only(bottom: 4),
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: _getAppointmentColor(appointment),
          borderRadius: BorderRadius.circular(6),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              DateFormat('hh:mm a').format(appointment.appointmentDateTime),
              style: const TextStyle(
                fontSize: 11,
                color: Colors.white,
                fontWeight: FontWeight.bold,
              ),
            ),
            Text(
              _getClientDisplayName(appointment),
              style: const TextStyle(fontSize: 12, color: Colors.white),
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
          ],
        ),
      ),
    );
  }

  /// Show all appointments for a specific date
  void _showAppointmentsForDate(
    DateTime date,
    List<AppointmentModel> appointments,
  ) {
    showDialog(
      context: context,
      builder: (context) => Dialog(
        child: Container(
          width: MediaQuery.of(context).size.width > 600
              ? 500
              : double.infinity,
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    DateFormat('MMMM dd, yyyy').format(date),
                    style: const TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.close),
                    onPressed: () => Navigator.pop(context),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              Text(
                '${appointments.length} Appointment${appointments.length != 1 ? 's' : ''}',
                style: TextStyle(fontSize: 14, color: Colors.grey[600]),
              ),
              const SizedBox(height: 16),
              Flexible(
                child: ListView.builder(
                  shrinkWrap: true,
                  itemCount: appointments.length,
                  itemBuilder: (context, index) {
                    final apt = appointments[index];
                    return Card(
                      margin: const EdgeInsets.only(bottom: 12),
                      child: InkWell(
                        onTap: () {
                          Navigator.pop(context); // Close list dialog
                          _showAppointmentDetails(apt); // Show details
                        },
                        child: Padding(
                          padding: const EdgeInsets.all(16),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Expanded(
                                    child: Text(
                                      _getClientDisplayName(apt),
                                      style: const TextStyle(
                                        fontSize: 16,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                  Container(
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: 8,
                                      vertical: 4,
                                    ),
                                    decoration: BoxDecoration(
                                      color: _getAppointmentColor(
                                        apt,
                                      ).withOpacity(0.1),
                                      borderRadius: BorderRadius.circular(8),
                                      border: Border.all(
                                        color: _getAppointmentColor(apt),
                                        width: 1,
                                      ),
                                    ),
                                    child: Text(
                                      _getAppointmentTypeLabel(
                                        apt.appointmentType,
                                      ),
                                      style: TextStyle(
                                        fontSize: 11,
                                        color: _getAppointmentColor(apt),
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 8),
                              Row(
                                children: [
                                  Icon(
                                    Icons.access_time,
                                    size: 16,
                                    color: Colors.grey[600],
                                  ),
                                  const SizedBox(width: 4),
                                  Text(
                                    DateFormat(
                                      'hh:mm a',
                                    ).format(apt.appointmentDateTime),
                                    style: TextStyle(
                                      fontSize: 14,
                                      color: Colors.grey[700],
                                    ),
                                  ),
                                ],
                              ),
                              if (apt.caseTitle != null) ...[
                                const SizedBox(height: 4),
                                Row(
                                  children: [
                                    Icon(
                                      Icons.folder_outlined,
                                      size: 16,
                                      color: Colors.grey[600],
                                    ),
                                    const SizedBox(width: 4),
                                    Expanded(
                                      child: Text(
                                        'Case: ${apt.caseTitle}',
                                        style: TextStyle(
                                          fontSize: 13,
                                          color: Colors.grey[700],
                                        ),
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ],
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),
              const SizedBox(height: 16),
              ElevatedButton.icon(
                onPressed: () {
                  Navigator.pop(context);
                  _createAppointmentForDate(date);
                },
                icon: const Icon(Icons.add),
                label: const Text('Add Appointment'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: calendarBlue,
                  foregroundColor: Colors.white,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  /// Show detailed appointment information
  void _showAppointmentDetails(AppointmentModel appointment) {
    showDialog(
      context: context,
      builder: (context) => Dialog(
        child: Container(
          width: MediaQuery.of(context).size.width > 600
              ? 500
              : double.infinity,
          padding: const EdgeInsets.all(24),
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      child: Text(
                        _getClientDisplayName(appointment),
                        style: const TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.close),
                      onPressed: () => Navigator.pop(context),
                    ),
                  ],
                ),
                const SizedBox(height: 24),
                // Appointment Type
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 12,
                    vertical: 8,
                  ),
                  decoration: BoxDecoration(
                    color: _getAppointmentColor(appointment).withOpacity(0.1),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(
                      color: _getAppointmentColor(appointment),
                      width: 1,
                    ),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(
                        _getAppointmentTypeIcon(appointment.appointmentType),
                        size: 18,
                        color: _getAppointmentColor(appointment),
                      ),
                      const SizedBox(width: 8),
                      Text(
                        _getAppointmentTypeLabel(appointment.appointmentType),
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                          color: _getAppointmentColor(appointment),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 24),
                // Client Email
                Builder(
                  builder: (context) {
                    try {
                      final clientEmail = _getClientEmail(appointment);
                      if (clientEmail.isNotEmpty && clientEmail.contains('@')) {
                        return Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            _buildDetailRow(
                              icon: Icons.email_outlined,
                              label: 'Email',
                              value: clientEmail,
                            ),
                            const SizedBox(height: 16),
                          ],
                        );
                      }
                    } catch (e) {
                      print('Error displaying client email: $e');
                    }
                    return const SizedBox.shrink();
                  },
                ),
                // Date and Time
                _buildDetailRow(
                  icon: Icons.calendar_today,
                  label: 'Date',
                  value: DateFormat(
                    'EEEE, MMMM dd, yyyy',
                  ).format(appointment.appointmentDateTime),
                ),
                const SizedBox(height: 16),
                _buildDetailRow(
                  icon: Icons.access_time,
                  label: 'Time',
                  value: DateFormat(
                    'hh:mm a',
                  ).format(appointment.appointmentDateTime),
                ),
                const SizedBox(height: 16),
                // Status
                _buildDetailRow(
                  icon: Icons.info_outline,
                  label: 'Status',
                  value: _getStatusLabel(appointment.status),
                  valueColor: _getStatusColor(appointment.status),
                ),
                // Case Information
                if (appointment.caseTitle != null) ...[
                  const SizedBox(height: 16),
                  _buildDetailRow(
                    icon: Icons.folder_outlined,
                    label: 'Case',
                    value: appointment.caseTitle!,
                  ),
                ],
                if (appointment.caseId != null) ...[
                  const SizedBox(height: 8),
                  Padding(
                    padding: const EdgeInsets.only(left: 32),
                    child: Text(
                      'Case ID: ${appointment.caseId}',
                      style: TextStyle(fontSize: 12, color: Colors.grey[600]),
                    ),
                  ),
                ],
                // Notes
                if (appointment.notes != null &&
                    appointment.notes!.isNotEmpty) ...[
                  const SizedBox(height: 16),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Icon(
                        Icons.note_outlined,
                        size: 20,
                        color: Colors.grey[600],
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Notes',
                              style: TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.w600,
                                color: Colors.grey[600],
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              appointment.notes!,
                              style: const TextStyle(
                                fontSize: 14,
                                color: Colors.black87,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ],
                const SizedBox(height: 24),
                // Actions
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    TextButton(
                      onPressed: () => Navigator.pop(context),
                      child: const Text('Close'),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildDetailRow({
    required IconData icon,
    required String label,
    required String value,
    Color? valueColor,
  }) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(icon, size: 20, color: Colors.grey[600]),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                label,
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  color: Colors.grey[600],
                ),
              ),
              const SizedBox(height: 4),
              Text(
                value,
                style: TextStyle(
                  fontSize: 14,
                  color: valueColor ?? Colors.black87,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  String _getAppointmentTypeLabel(String type) {
    switch (type) {
      case 'in_office':
      case 'meeting_office':
        return 'Meeting in Office';
      case 'phone_call':
        return 'Phone Call';
      case 'online_meeting':
        return 'Online Meeting';
      case 'hearing':
      case 'hearing_court':
        return 'Hearing in Court';
      case 'consultation':
        return 'Consultation';
      default:
        // Format: convert snake_case to Title Case
        return type
            .replaceAll('_', ' ')
            .split(' ')
            .map((word) {
              return word.isEmpty
                  ? ''
                  : word[0].toUpperCase() + word.substring(1);
            })
            .join(' ');
    }
  }

  IconData _getAppointmentTypeIcon(String type) {
    switch (type) {
      case 'in_office':
      case 'meeting_office':
        return Icons.business;
      case 'phone_call':
        return Icons.phone;
      case 'online_meeting':
        return Icons.video_call;
      case 'hearing':
      case 'hearing_court':
        return Icons.gavel;
      case 'consultation':
        return Icons.meeting_room;
      default:
        return Icons.event;
    }
  }

  String _getStatusLabel(String status) {
    switch (status.toLowerCase()) {
      case 'pending':
        return 'Pending';
      case 'confirmed':
      case 'scheduled':
        return 'Confirmed';
      case 'completed':
        return 'Completed';
      case 'cancelled':
        return 'Cancelled';
      case 'rescheduled':
        return 'Rescheduled';
      default:
        return status;
    }
  }

  Color _getStatusColor(String status) {
    switch (status.toLowerCase()) {
      case 'pending':
        return Colors.orange;
      case 'confirmed':
      case 'scheduled':
        return Colors.blue;
      case 'completed':
        return Colors.green;
      case 'cancelled':
        return Colors.red;
      case 'rescheduled':
        return Colors.orange;
      default:
        return Colors.grey;
    }
  }
}
