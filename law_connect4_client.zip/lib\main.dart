import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart' show kDebugMode, debugPrint, kIsWeb;

import 'firebase_options.dart';
import 'controllers/auth_controller.dart';
import 'theme/app_theme.dart';
import 'pages/splash_screen.dart';
import 'pages/client/client_landing_page.dart';
import 'pages/staff/staff_landing_page.dart';
import 'pages/staff/staff_application_page.dart';
import 'pages/staff/staff_complete_registration_page.dart';
import 'pages/staff/staff_application_status_page.dart';
import 'pages/attorney/attorney_landing_page.dart';
import 'pages/auth/login_page.dart';
import 'pages/auth/signup_page.dart';
import 'pages/auth/otp_verification.dart';
import 'pages/admin/admin_dashboard.dart';
import 'pages/attorney/attorney_dashboard.dart';
import 'pages/staff/staff_dashboard.dart';
import 'screens/client/dashboard_screen_with_nav.dart';
import 'services/notification_service.dart';
import 'services/fcm_service.dart';
import 'firebase_messaging_handler.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'supabase/supabase_bootstrap.dart';
import 'services/supabase_service.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  try {
    await Firebase.initializeApp(
      options: DefaultFirebaseOptions.currentPlatform,
    );
    if (kDebugMode) {
      debugPrint('✅ Firebase initialized successfully');
    }

    // Configure Firestore settings
    try {
      // Wait longer for Firestore to fully initialize
      await Future.delayed(const Duration(milliseconds: 500));

      if (!kIsWeb) {
        // For mobile, enable persistence
        FirebaseFirestore.instance.settings = const Settings(
          persistenceEnabled: true,
          cacheSizeBytes: Settings.CACHE_SIZE_UNLIMITED,
        );
      }

      // For web, disable persistence to avoid internal assertion errors
      if (kIsWeb) {
        try {
          FirebaseFirestore.instance.settings = const Settings(
            persistenceEnabled: false,
          );
        } catch (e) {
          // Settings might not be changeable on web, that's okay
          if (kDebugMode)
            debugPrint('⚠️ Could not set web Firestore settings: $e');
        }
      }

      if (kDebugMode) debugPrint('✅ Firestore settings configured');
    } catch (e) {
      if (kDebugMode)
        debugPrint('⚠️ Firestore settings configuration failed: $e');
      // Continue anyway - Firestore will work with default settings
    }
  } catch (e) {
    if (kDebugMode) debugPrint('⚠️ Firebase initialization failed: $e');
  }

  // Supabase (PostgreSQL / Storage) — second backend alongside Firestore (manual setup in dashboard).
  try {
    await initializeSupabase();
    if (isSupabaseClientReady) {
      await SupabaseService.instance.verifyProjectOnline();
    }
  } catch (e) {
    if (kDebugMode) debugPrint('⚠️ Supabase initialization failed: $e');
  }

  // Background handler is Android/iOS only; registering on web throws and
  // prevents runApp(), which shows a blank page in the browser.
  if (!kIsWeb) {
    FirebaseMessaging.onBackgroundMessage(firebaseMessagingBackgroundHandler);
    if (kDebugMode) {
      debugPrint('✅ Background message handler registered');
    }
  }

  // Initialize notification service
  try {
    await NotificationService().initialize();
    if (kDebugMode) {
      debugPrint('✅ Notification service initialized successfully');
    }
  } catch (e) {
    if (kDebugMode) {
      debugPrint('⚠️ Notification service initialization failed: $e');
    }
  }

  // Initialize FCM service for push notifications
  try {
    final fcmService = FCMService();
    await fcmService.initialize();
    if (kDebugMode) {
      debugPrint('✅ FCM service initialized successfully');
    }
  } catch (e) {
    if (kDebugMode) {
      debugPrint('⚠️ FCM service initialization failed: $e');
    }
  }

  runApp(const LawConnectApp());
}

class LawConnectApp extends StatelessWidget {
  const LawConnectApp({super.key});

  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Law Connect',
      theme: AppTheme.lightTheme,

      // Ensure AuthController is available app-wide
      initialBinding: BindingsBuilder(() {
        Get.put(AuthController(), permanent: true);
        Get.put(SupabaseService.instance, permanent: true);
        if (kDebugMode) debugPrint('✅ AuthController initialized globally');
      }),

      // Define routes to handle web URL routing
      getPages: [
        GetPage(name: '/', page: () => const SplashScreen()),
        GetPage(
          name: '/ClientLanding',
          page: () => const ClientLandingPage(),
        ),
        GetPage(name: '/StaffLanding', page: () => const StaffLandingPage()),
        GetPage(name: '/StaffApply', page: () => const StaffApplicationPage()),
        GetPage(
          name: '/StaffCompleteRegistration',
          page: () => const StaffCompleteRegistrationPage(),
        ),
        GetPage(
          name: '/StaffApplicationStatus',
          page: () => const StaffApplicationStatusPage(),
        ),
        GetPage(
          name: '/AttorneyLanding',
          page: () => const AttorneyLandingPage(),
        ),
        GetPage(name: '/LoginPage', page: () => const LoginPage()),
        GetPage(name: '/Signup', page: () => const SignupPage()),
        GetPage(
          name: '/ClientSignup',
          page: () => const SignupPage(),
        ), // Keep for backward compatibility
        GetPage(
          name: '/OtpVerification',
          page: () => const OtpVerificationPage(),
        ),
        GetPage(name: '/AdminDashboard', page: () => const AdminDashboard()),
        GetPage(
          name: '/AttorneyDashboard',
          page: () => const AttorneyDashboard(),
        ),
        GetPage(name: '/StaffDashboard', page: () => const StaffDashboard()),
        GetPage(
          name: '/ClientDashboard',
          page: () => const DashboardScreenWithNav(),
        ),
      ],

      // Ignore unknown routes to prevent errors
      unknownRoute: GetPage(
        name: '/notfound',
        page: () => const SplashScreen(),
      ),

      // Use getPages + initialRoute only (GetX: do not set home together with this).
      initialRoute: '/',
    );
  }
}
