import 'package:cloud_functions/cloud_functions.dart';

class CourtEmailQueueService {
  final FirebaseFunctions _functions;

  CourtEmailQueueService({FirebaseFunctions? functions})
      : _functions = functions ?? FirebaseFunctions.instance;

  Future<Map<String, dynamic>> processQueueItem({
    required String docId,
    required String action, // 'schedule' | 'ignore'
    String? titlePrefix,
  }) async {
    final callable = _functions.httpsCallable('processCourtEmailQueue');
    final res = await callable.call({
      'docId': docId,
      'action': action,
      if (titlePrefix != null) 'titlePrefix': titlePrefix,
    });
    final data = res.data as Map<dynamic, dynamic>?;
    if (data == null) return <String, dynamic>{};
    return data.map((k, v) => MapEntry(k.toString(), v));
  }
}

