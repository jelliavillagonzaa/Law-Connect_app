import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../../widgets/attorney/case_requests_widget.dart';
import '../../theme/app_theme.dart';
import 'attorney_create_case_screen.dart';

class AttorneyCaseRequestsScreen extends StatelessWidget {
  const AttorneyCaseRequestsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) {
      return Scaffold(
        appBar: AppBar(
          title: const Text('Case Requests'),
          backgroundColor: AppTheme.royalBlue,
          foregroundColor: Colors.white,
        ),
        body: const Center(child: Text('Please log in to view case requests')),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Case Requests / Inquiries'),
        backgroundColor: AppTheme.royalBlue,
        foregroundColor: Colors.white,
        actions: [
          IconButton(
            icon: const Icon(Icons.add),
            tooltip: 'Create Case',
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const AttorneyCreateCaseScreen(),
                ),
              ).then((created) {
                if (created == true && context.mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('Case created successfully!'),
                      backgroundColor: Colors.green,
                    ),
                  );
                }
              });
            },
          ),
        ],
      ),
      body: CaseRequestsWidget(
        attorneyId: user.uid,
        isMobile: MediaQuery.of(context).size.width < 800,
      ),
    );
  }
}
